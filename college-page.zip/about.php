<?php
include 'links.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
       <style>
           body{
            background-color:#A20A3A;
        }
        .toptitle{
            background-color: #3D1558;
        }
        hr{
            border:2px solid white;
        }
       </style> 
</head>
<body>
<div class="toptitle py-1 text-center text-white">
     <a class="text-right float-left" href="index.php"><img src="images/logo.png"/></a>
     <a href="login.php"><button type="button" class="btn my-1 mr-2 mx-1 btn-outline-primary float-right text-white">Login</button></a>
    <dl>
  <dt>Single Shop</dt>
  <dd>सब कुछ मिलेगा </dd>
    </dl>
    </div>
    <marquee class="text-warning font-weight-bold ">
        <div class="pt-2"> Welcome To Single Shop...  STAY HOME & STAY SAFE , IF YOU NEED TO LEAVE YOUR HOUSE, WEAR A MASK DUE TO COVID-19 !!!</div>
    </marquee>   
    <hr>   
<div class="btn-group-justified mb-3 text-center">
<a href="index.php"><button type="button" class="btn btn-outline-primary text-white">Single Shop</button></a>
</div>
<div class="container-fluid container-justified">
    
  <div class="row">
    <div class="col-sm-12 col-12 col-lg-4 col-md-6"></div>
    <div class="col-sm-12 col-12 col-lg-4 col-md-6">

     <section class="toptitle">
     <div class="border bg-success rounded card text-center text-white">
    <h3>Welcome To Single Shop</h3>
    </div>
    <div class="card mx-3 mt-3 text-white border rounded" >
    <img class="card-img-top d-block w-100" src="images/ceo.png" alt="CEO VIKAS" style="width:100%">
    <div class="card-body border  text-center">
    <br>
    <p class="card-text">
Hi,
I'm Virat Goyal Founder & CEO of Single Shop and  Kumar Somesh is Co-founder of Single Shop.<br>
<br>
Virat Goyal :- I have a 2-year experience of online products selling and also network marketing.</p><br>
<br>
<p class="bg-success">What work do we do-</p>
<P>sells online products.</P>
<p class="bg-success">Our main purpose-</p>
<p>The main purpose of our website is to connect Hartley with the whole world.</p>
<p class="bg-success">What we sell now and what we sell next-</p>
<p>Our website currently deals with fashion related products.we will launch many more products in the future.</p>
    <p class="bg-success">Return & Refund Policy</p>
<p class="mt-3">Once the products reach you and later you see any kind of disturbance, you can complaint the E-mail id of the Single Shop <a class="text-white" href="mailto:infosingleshop@gmail.com"><br><div class="bg-success">infosingleshop@gmail.com </div></a>We will solve your problem within 7 days. For this do keep the products tags and packing inact.
          Thank You !</p>

     </div>
     </div>  
     
     
     
         </section>

</div>
    <div class="col-sm-12 col-12 col-lg-4 col-md-6"></div>
  </div>
</div>


      







<?php
include 'footer.php';
?>
</body>
</html>
