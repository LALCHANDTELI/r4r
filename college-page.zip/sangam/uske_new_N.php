<?php
session_start();
include 'connection.php';
error_reporting(0);
if(!isset($_COOKIE['visitor_counts']))
{
    include '../connection.php';
    $count = "counter";
    setcookie('visitor_counts',$count, time() + (3 * 365 * 24 * 60 * 60), "/" );
    $update_counter = "UPDATE visitor set counter =  counter + 1 where id = '1'";
    $query = mysqli_query($mydbconnection,$update_counter);
}
if(!isset($_COOKIE['visitor1']))
{
    $count = "counter";
    setcookie('visitor1',$count, time() + (3 * 365 * 24 * 60 * 60) );
    $update_counter = "UPDATE visitor set counter1 =  counter1 + 1 where id = '1'";
    $query = mysqli_query($myunconnection,$update_counter);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    </head>
    <body class="bg-dark">
 
    <nav class="border border-warning rounded bg-dark mx-3 mt-3">
    <h3 class="text-center text-primary">   <a href="index.php"><img src="images/left.png"/></a>Uske New Number...</h3>
   </nav>
    <nav class="container">
      <nav class="mt-3">
          <p class="text-center text-warning">Add Only BTech Batch 2018 !!!</p>
      </nav>
  </nav>
    <div class="border bg-secondary rounded card my-5 mx-5">
  <div class="card-body">
    <form action="" method="post">
  <div class="form-group">
    <label>Naam :</label>
    <input type="text" name="un_naam" class="form-control" required placeholder="Enter Naam">
    </div>
    <div class="form-group">
    <label>Number :</label>
    <input type="number" name="un_number" class="form-control" required placeholder="Enter Number">
  </div>
  <button name="submit" type="submit" class="btn btn-success">Submit</button>
</form>
  </div>
</div>
<div class="my-3 text-center">
<footer>
<h3> <a href="https://mycollagepage.000webhostapp.com/">mycollagepage.com</a></h3>
</footer>
</div>
</body>
</html>


<?php
if(isset($_POST['submit'])){
    $uske_n_naam = $_POST['un_naam'];
    $uske_n_number = $_POST['un_number'];
    $numlength = mb_strlen($uske_n_number);
    $select = "select uske_number from sangam";
  $selectqueryfire = mysqli_query($myunconnection,$select);
  $numofrow = mysqli_num_rows($selectqueryfire);
  $id = 1;
  if($numlength==10){
    while($numofrow!=0){
        $select2 = "select uske_number from sangam where id = $id";
        $selectqueryfire2 = mysqli_query($myunconnection,$select2);
        $selectarray2 = mysqli_fetch_array($selectqueryfire2);
        $db_u_number = $selectarray2['uske_number'];
        while($db_u_number==""){
            $id ++;
            $select2 = "select uske_number from sangam where id = $id";
        $selectqueryfire2 = mysqli_query($myunconnection,$select2);
        $selectarray2 = mysqli_fetch_array($selectqueryfire2);
        $db_u_number = $selectarray2['uske_number'];
        }
        if($db_u_number === $uske_n_number){
            $_SESSION['sangam_already'] ="already";
        }
        $id ++;
        $numofrow --;
      }

      if(isset($_SESSION['sangam_already'])){
        unset($_SESSION['sangam_already']);
        ?>
        <script>
            alert("Number Already Saved");
            location.replace("uske_new_N.php");
        </script>
        <?php
        }else{
            $inser = "INSERT INTO sangam (uska_naam ,uske_number) VALUES ('$uske_n_naam' ,'$uske_n_number')";
            $inserqueryfire = mysqli_query($myunconnection,$inser);
                ?>
                <script>
                alert("Number Inserted!!!");
                    location.replace("index.php");
                </script>
                <?php
        }
      }
      else{
        ?>
    <script>
        alert("Enter Right Number");
    </script>
    <?php
      }
      
  }
?>