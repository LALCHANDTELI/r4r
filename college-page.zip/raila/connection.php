<?php
$dbhost = "localhost";
$dbuser = "id13308335_un";
$dbpassword = "yr=AZkGX?NY]?c|6";
$dbname = "id13308335_uske_number";
$myunconnection = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

if($myunconnection)
{
}
else
{
    ?>
    <script>
        alert("you are offline now");
    </script>
    
    <?php

}

?>