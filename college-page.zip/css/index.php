<?php
header('Refresh: 5; URL=http://mycollagepage.000webhostapp.com');
include '../links.php';
?>
<head>
<title>ERROR:404</title>
</head>
<body class="bg-dark">
<section>
    <div class="container col-lg-4 col-md-6 col-sm-12 col-12">
    <div class="my-2 mx-2 card border rounded">
    <div class="card-body text-center bg-warning text-black">
    <h4 class="card-title">404 ERROR: FILE NOT FOUNF...</h4>
    <p class="card-text">The URL You Requested Was Not Found.<br>
    Did You Mean To Type http://mycollagepage.com ?  You Will Be Automatically Redirected There In Five Seconds.</p>
    <img class="card-img-top d-block w-100" src= "../images/error404.png" alt="ERROR 404:" style="width:100%">
     </div>
     </div>    
     </div>   
    </section>
    </body>