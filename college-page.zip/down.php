<?php
include 'links.php';
include 'connection.php';
error_reporting(0);
?>

<title>SITE DOWN</title>
<div class="card mx-3 mt-3" >
          <h4 class="rounded border card-title bg-warning my-3 text-center text-uppercase text-dark">temporarily unavailable</h4>
        
<div class="card-body text-center">
              <h4>Dear User</h4>
              <p class="card-text">This Site Is Temporarily Unavailable Due To Some Errors.</p>
              <img class="card-img d-block w-100" src="images/down.jpg" alt="DOWN" style="width:100%">
              <p class="card-text mt-3">we will fix it. please come back soon.</p>
              </div>
</div>
