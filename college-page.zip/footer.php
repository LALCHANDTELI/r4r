<footer>
    <div class="container container-fluids">
  <h2 class="text-center about mt-3 mb-2">About This Site</h2>
  <div class="card container container-fluids">
    <img class="card-img-top my-photo mt-3" src="images/r4r.gif" alt="R4R" width="900" height="300">
    <div class="card-body">
      <h4 class="card-title">ROOMS FOR RENT</h4>
      <p class="card-text">This Site Only For Those Students That Away From Home And Parents During Studying.<br> And They Need Immediately Secure Clean And Silence Environment Room For Rent For Study Purpose.
<br>So Don't Worry Come On My Site Search Your Room And Save Your  Precious Time And Continue Your Study.<br>Now NO Need To Roaming street street For Rooms.</p>
    </div>
  </div>
    </div>

   <img class="footer mt-3 img-fluid" src="images/rooms.gif" alt="R4R" style="width:100%" >
 </footer>