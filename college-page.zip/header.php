<div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/main-logo.gif" alt="R4R-logo" width="900" height="300">
      <div class="carousel-caption">
        <h3>ROOMS FOR RENT</h3>
        <p>MAKE SOME EASY</p>
      </div>   
    </div>
</div>